Audio Controls Extension
=====================

Adds default html5 controls to audio elements within Overcast.

# Future features

1. Specify list of pages to add this feature too, not just overcast.fm
2. Figure out build & packaging.

Built off of [Chrome Extensions Box](https://github.com/onikienko/chrome-extensions-box)

# Reasoning

Originally built to automatically add volume controls to the [Overcast.fm](https://overcast.fm) web player.
