<!doctype html>
<meta charset=utf8>
<title>Service discontinued</title>

<body style="font-family: georgia; font-size: 1.1em; max-width: 45em">

<h1>Service discontinued</h1>

<p>Keeping the uglify service running while somehow protecting my lightweight VM from (often unintentional) denial-of-service attacks by people sending lots of requests or really huge sources was too much of a burden. I've shut it down. You can install <a href="https://www.npmjs.com/package/uglify-js">uglify-js</a> locally with <code>npm install -g uglify-js</code> instead.</p>

</body>
